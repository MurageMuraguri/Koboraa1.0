CREATE DATABASE koboraa;
USE koboraa;

CREATE TABLE users(
userID int(5) not null auto_increment,
firstName varchar(50) not null,
lastName varchar (50) not null,
userMail varchar(50) not null,
userPass varchar(50) not null,
 primary key (userID)
);